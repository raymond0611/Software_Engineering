﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Record_System
{
    public partial class Teacher : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataAdapter da;
        DataTable dt;

        public Teacher()
        {
            InitializeComponent();
        }
        void GetStudents()
        {
            con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_users.mdb");
            dt = new DataTable();
            da = new OleDbDataAdapter("SELECT *FROM tbl_students", con);
            con.Open();
            da.Fill(dt);
            dgwStudents.DataSource = dt;
            con.Close();
        }
        private void label5_Click(object sender, EventArgs e)
        {

        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string query = "UPDATE tbl_students " +
                "SET Modeling=@modeling, Engineering=@engineering, Animation=@animation, Exam=@exam, GPA=@gPA " +
                "WHERE Id=@id";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@modeling", txtModeling.Text);
            cmd.Parameters.AddWithValue("@engineering", txtEngineering.Text);
            cmd.Parameters.AddWithValue("@animation", txtAnimation.Text);
            cmd.Parameters.AddWithValue("@exam", txtExam.Text);
            cmd.Parameters.AddWithValue("@gPA", txtGPA.Text);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Student Information updated");
            GetStudents();
        }

        private void dgwStudents_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }

        private void dgwStudents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void Teacher_Load_1(object sender, EventArgs e)
        {
            GetStudents();
        }

        private void dgwStudents_CellEnter_1(object sender, DataGridViewCellEventArgs e)
        {
            txtId.Text = dgwStudents.CurrentRow.Cells[0].Value.ToString();
            txtStudentId.Text = dgwStudents.CurrentRow.Cells[1].Value.ToString();
            txtModeling.Text = dgwStudents.CurrentRow.Cells[7].Value.ToString();
            txtEngineering.Text = dgwStudents.CurrentRow.Cells[8].Value.ToString();
            txtAnimation.Text = dgwStudents.CurrentRow.Cells[9].Value.ToString();
            txtExam.Text = dgwStudents.CurrentRow.Cells[10].Value.ToString();
            txtGPA.Text = dgwStudents.CurrentRow.Cells[11].Value.ToString();
        }
    }
}
