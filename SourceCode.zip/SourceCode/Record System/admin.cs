﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Record_System
{
    public partial class admin : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataAdapter da;
        DataTable dt;

        public admin()
        {
            InitializeComponent();
        }

        void GetStudents()
        {
            con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_users.mdb");
            dt = new DataTable();
            da = new OleDbDataAdapter("SELECT *FROM tbl_students", con);
            con.Open();
            da.Fill(dt);
            dgwStudents.DataSource = dt;
            con.Close();
        }
     

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void teacher_Load(object sender, EventArgs e)
        {
            GetStudents();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO tbl_students (StudentID, Name, Address, Age, Sex, BirthDate, Modeling, Engineering, Animation, Exam, GPA) VALUES " +
            "(@studentID, @name, @address, @age, @sex, @birthDate, @modeling, @engineering, @animation, @exam, @gPA)";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@studentID", txtStudentId.Text);
            cmd.Parameters.AddWithValue("@name", txtName.Text);
            cmd.Parameters.AddWithValue("@address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@age", txtAge.Text);
            cmd.Parameters.AddWithValue("@sex", txtSex.Text);
            cmd.Parameters.AddWithValue("@birthDate", dtpBirthDate.Value);
            cmd.Parameters.AddWithValue("@modeling", txtModeling.Text);
            cmd.Parameters.AddWithValue("@engineering", txtEngineering.Text);
            cmd.Parameters.AddWithValue("@animation", txtAnimation.Text);
            cmd.Parameters.AddWithValue("@exam", txtExam.Text);
            cmd.Parameters.AddWithValue("@gPA", txtGPA.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Student Information inserted");
            GetStudents();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string query = "UPDATE tbl_students " +
                "SET StudentID=@studentID, Name=@name, Address=@address, Age=@age, Sex=@sex, BirthDate=@birthDate, Modeling=@modeling, Engineering=@engineering, Animation=@animation, Exam=@exam, GPA=@gPA " +
                "WHERE Id=@id";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@studentID", txtStudentId.Text);
            cmd.Parameters.AddWithValue("@name", txtName.Text);
            cmd.Parameters.AddWithValue("@address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@age", txtAge.Text);
            cmd.Parameters.AddWithValue("@sex", txtSex.Text);
            cmd.Parameters.AddWithValue("@birthDate", dtpBirthDate.Value);
            cmd.Parameters.AddWithValue("@modeling", txtModeling.Text);
            cmd.Parameters.AddWithValue("@engineering", txtEngineering.Text);
            cmd.Parameters.AddWithValue("@animation", txtAnimation.Text);
            cmd.Parameters.AddWithValue("@exam", txtExam.Text);
            cmd.Parameters.AddWithValue("@gPA", txtGPA.Text);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Student Information updated");
            GetStudents();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM tbl_students WHERE Id=@id";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Student deleted");
            GetStudents();
        }

        private void dgwStudents_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtId.Text = dgwStudents.CurrentRow.Cells[0].Value.ToString();
            txtStudentId.Text = dgwStudents.CurrentRow.Cells[1].Value.ToString();
            txtName.Text = dgwStudents.CurrentRow.Cells[2].Value.ToString();
            txtAddress.Text = dgwStudents.CurrentRow.Cells[3].Value.ToString();
            txtAge.Text = dgwStudents.CurrentRow.Cells[4].Value.ToString();
            txtSex.Text = dgwStudents.CurrentRow.Cells[5].Value.ToString();
            dtpBirthDate.Text = dgwStudents.CurrentRow.Cells[6].Value.ToString();
            txtModeling.Text = dgwStudents.CurrentRow.Cells[7].Value.ToString();
            txtEngineering.Text = dgwStudents.CurrentRow.Cells[8].Value.ToString();
            txtAnimation.Text = dgwStudents.CurrentRow.Cells[9].Value.ToString();
            txtExam.Text = dgwStudents.CurrentRow.Cells[10].Value.ToString();
            txtGPA.Text = dgwStudents.CurrentRow.Cells[11].Value.ToString();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            DataView dv = dt.DefaultView;
            dv.RowFilter = "Name LIKE '%" + txtSearch.Text + "%'";
            dgwStudents.DataSource = dv;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtModeling_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void txtEngineering_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void txtAnimation_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void txtExam_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgwStudents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtStudentId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
