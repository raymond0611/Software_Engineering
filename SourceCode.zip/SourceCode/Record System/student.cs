﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Record_System
{
    public partial class student : Form
    {
       OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_users.mdb");
        OleDbCommand cmd;
        public student()
        {
            InitializeComponent();
        }

        private void student_Load(object sender, EventArgs e)
        {

        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = new OleDbCommand("SELECT ID,Modeling, Engineering, Animation, Exam, GPA FROM tbl_students WHERE StudentID=@studentID AND Password=@password", con);
            cmd.Parameters.AddWithValue("@studentID", txtStudentId.Text);
            cmd.Parameters.AddWithValue("@password", txtPassword.Text);
            OleDbDataReader reader;
            reader = cmd.ExecuteReader();
            if(reader.Read())
            {
                txtId.Text = reader["ID"].ToString();
                txtModeling.Text = reader["Modeling"].ToString();
                txtEngineering.Text = reader["Engineering"].ToString();
                txtAnimation.Text = reader["Animation"].ToString();
                txtExam.Text = reader["Exam"].ToString();
                txtGPA.Text = reader["GPA"].ToString();
            }
            else
            {
                MessageBox.Show("No Data found");
            }
            con.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string query = "UPDATE tbl_students " +
               "SET Address=@address, Age=@age WHERE Id=@id";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@age", txtAge.Text);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtId.Text));
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Your Information updated");
        }

        private void btnBackToLogin_Click(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }
    }
}
